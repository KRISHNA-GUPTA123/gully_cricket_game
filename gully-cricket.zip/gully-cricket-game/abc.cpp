/*
PROGRAMMED BY: KRISHNA GUPTA



*/

#include<iostream>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<conio.h>
using namespace std;

int main(){
    int randomvalue ;
    int sum = 0 ;
    char abc;
   
    srand(time(NULL));
    for (int i = 0; i < 6; i++)
    {       cout<< " Hit space to play the ball   "<<endl;
                     abc= getch();
              if(abc==' '){
                  
              randomvalue = (rand()%7);
              cout<< "Perfect you scored:   "<< randomvalue << endl;
              sum = sum + randomvalue;
              } else
              {
                  cout<<"wrong input";
                  break;
              }
              
    }
    cout<<"total score :"<<sum;
    
           
    return 0;
}